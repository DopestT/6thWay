import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://6thway.com',
  output: 'static',
});
