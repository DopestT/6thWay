---
title: "Emergency Authority, No Congressional Review: Inside the $151.8M Bomb Sale to Israel"
slug: "arms-pipeline-emergency-bomb-sale-israel-2026"
date: "2026-06-21"
beat: "arms-pipeline"
tags: ["arms-sales", "israel", "state-department", "congressional-oversight", "munitions"]
dek: "The State Department waived the normal congressional review window to approve a $151.8 million bomb sale — the latest in a pattern of accelerating arms transfers to Israel in 2026."
summary: "A new State Department notification shows a $151.8 million sale of 12,000 bomb bodies to Israel approved under emergency authority, bypassing the congressional review period normally required for major arms sales. It's the latest entry in a 2026 pipeline that includes a $6.67 billion package approved in January."
sources:
  - name: "U.S. Department of State — Israel: Munitions and Munitions Support notification"
    url: "https://www.state.gov/israel-munitions-and-munitions-support"
  - name: "U.S. Department of State — FY2025 U.S. Arms Transfers and Defense Trade"
    url: "https://www.state.gov/releases/bureau-of-political-military-affairs/2026/03/fiscal-year-2025-u-s-arms-transfers-and-defense-trade"
  - name: "Bloomberg — State Department Approves Arms Sales to Israel, Saudi Arabia"
    url: "https://www.bloomberg.com/news/articles/2026-01-31/state-department-approves-arms-sales-to-israel-saudi-arabia"
  - name: "Forum on the Arms Trade — Major Arms Sales Notification Tracker"
    url: "https://www.forumarmstrade.org/major-arms-sales-notifications-tracker.html"
data_through: "2026-04-02"
tracker_update: false
related_slugs: []
status: "draft"
---

# Emergency Authority, No Congressional Review: Inside the $151.8M Bomb Sale to Israel

**The State Department waived the normal congressional review window to approve a $151.8 million bomb sale — the latest in a pattern of accelerating arms transfers to Israel in 2026.**

## The Numbers

- **$151.8 million** — total estimated cost of the sale
- **12,000** BLU-110A/B 1,000-pound general purpose bomb bodies requested by the Government of Israel
- **0 days** of congressional review — the Secretary of State invoked an emergency determination under Section 36(b) of the Arms Export Control Act, waiving the review period entirely
- **Repkon USA** (Garland, Texas) — the principal contractor
- **$6.67 billion** — separate Israel arms package approved by the same department on January 30, 2026, covering Apache attack helicopters and light tactical vehicles
- **$226.8 billion** — total U.S. direct commercial arms sale authorizations for FY2025, up 12.9% from FY2024

## What Happened

Under the Arms Export Control Act, major foreign military sales are supposed to go through a congressional notification period — 15 or 30 days, depending on the recipient country — during which Congress can in theory block the sale with a joint resolution. That window exists specifically so lawmakers have a chance to object before a sale becomes final.

For this $151.8 million sale of bomb bodies to Israel, the State Department skipped it. The notification states that the Secretary of State determined an emergency existed requiring immediate sale, which under the law allows the review requirement to be waived outright. The stated justification is that the sale serves U.S. national security interests by supporting a "strategic regional partner."

This isn't an isolated case. It follows a $6.67 billion package approved on January 30, 2026 — split into four parts covering 30 AH-64E Apache helicopters, 3,250 Joint Light Tactical Vehicles, and AW119Kx light utility helicopters — and sits inside a broader FY2025 picture in which total U.S. arms transfer authorizations rose to $226.8 billion, continuing a multi-year upward trend (the three-year rolling average for FY2023–25 was $195.0 billion, a 14.3% increase over the prior three-year period).

## Why It Matters

Congressional review isn't a formality — it's the one built-in check that exists between a State Department sign-off and a completed arms transfer. Emergency waivers remove that check entirely, and they're becoming a more routine tool rather than an exceptional one. Tracking how often this authority gets used, and for what, is the difference between knowing a sale happened and knowing whether anyone outside the executive branch had a chance to stop it.

This is the first entry in 6th Way's Arms Pipeline tracker. Future updates will follow this and other notified sales from approval through delivery, and will flag every case where the standard review window was waived.

## Sources & Methodology

Figures are drawn directly from the State Department's official FMS notification for this sale and the department's FY2025 Arms Transfers and Defense Trade report. The January 2026 package figures are corroborated by Bloomberg's reporting on the State Department's announcement. The Forum on the Arms Trade's notification tracker was used to confirm the standard review timeline this sale bypassed. No figures in this article are estimated or inferred — all are stated directly in the cited primary sources.
