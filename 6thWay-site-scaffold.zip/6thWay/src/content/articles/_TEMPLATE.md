---
title: ""                      # required — punchy, accountability-framed (e.g. "Apache Helicopters, $6.67B: Inside the Latest Arms Sale to Israel")
slug: ""                       # auto-generate from title, kebab-case
date: ""                       # ISO 8601, publish date
beat: ""                       # one of: arms-pipeline | who-profits | empire-tracker | gaza-reconstruction | west-bank-settlements | aipac-money-outcome | media-bias
tags: []                       # 3-6 tags, lowercase
dek: ""                        # one-sentence subhead, the "why this matters now" line
summary: ""                    # 2-3 sentence SEO/social summary, no editorializing
sources:                       # required — every figure in the body must trace to one of these
  - name: ""
    url: ""
data_through: ""               # date the underlying data was last updated (FEC/State Dept/USAspending/etc.)
tracker_update: false          # true if this is a recurring update to an existing tracker
related_slugs: []              # slugs of prior articles in the same beat, for the "what changed" section
status: "draft"                # draft | review | published
---

# {{title}}

**{{dek}}**

## The Numbers (lead with this — always first)

- [Headline figure 1, sourced]
- [Headline figure 2, sourced]
- [Headline figure 3, sourced]

## What Happened

[2-4 short paragraphs. Plain sentences. State the fact, then the source, then the implication — in that order. No rhetorical questions. No throat-clearing.]

## What Changed Since Last Update *(only if tracker_update: true)*

[1-2 paragraphs comparing this update to the prior one in this series — delta, not just a restatement.]

## Why It Matters

[1-2 paragraphs. This is the one place editorial framing is allowed — but it must follow directly from the data above, not introduce new claims. This is also where the foreign-policy-to-domestic-cost link belongs when it's earned by the facts (e.g., dollar figures, specific tradeoffs) — never as a rhetorical flourish without a number behind it.]

## Sources & Methodology

[Plain-language list of where every number came from and how it was calculated/aggregated. This section is non-negotiable — it's what makes 6th Way harder to dispute than commentary-only outlets.]

---

### Generation constraints for the automation
- Every factual claim needs a source in the `sources` field — no claim without a citation.
- No unverified figures, no rounding that changes magnitude, no quoting designated terrorist organizations' claims as fact.
- 600–900 words for a standard update. Longer only if `tracker_update: false` (new investigation).
- Tone: adversarial toward power, not toward people. Critique institutions, policies, and money flows — not individuals' identities.
- If the data needed to support a claim isn't available from a listed public source, the section gets cut, not filled with speculation.
