---
title: ""                      # required — reflective, thesis-driven (not a data headline)
slug: ""
date: ""                       # always a Sunday
week_ending: ""                # ISO date, the week this editorial closes out
threads_covered: []            # slugs of the week's 3x/week articles this editorial ties together
dek: ""                        # the through-line in one sentence
summary: ""
sources:
  - name: ""
    url: ""
status: "draft"
---

# {{title}}

**{{dek}}**

## Opening Thread

[1-2 paragraphs. Start from a specific, concrete fact or image from the week's coverage — not an abstraction. Ground the reader before widening the lens.]

## Connecting the Threads

[3-5 paragraphs. This is the Sunday editorial's actual job: take 2-4 stories that ran separately during the week (one from anti-imperialism, one from Israel-Palestine, ideally something domestic) and show the throughline between them. The model here is the foreign-cost/domestic-cost link — a dollar figure or policy choice abroad mapped to a concrete tradeoff at home. Every connection needs to be earned by a fact already published this week, not asserted fresh.]

## The Pattern, Not Just the Story

[1-2 paragraphs. Zoom out: what does this week's news reveal about the structure (military-industrial complex, lobbying influence, bipartisan continuity) rather than just the individual event? This is where 6th Way can take a clearer interpretive stance than the Tuesday/Thursday trackers — but it should read as analysis, not as a call to outrage.]

## What We're Watching Next Week

[Short, concrete list — 2-4 bullets. Specific things to track: an upcoming vote, an expected FMS notification, a reconstruction fund disbursement deadline, a settlement approval hearing. This keeps the editorial functional, not just reflective, and seeds the next week's tracker updates.]

## Sources

[Every prior-week article referenced should be linked via `threads_covered`; any new sourcing introduced in this editorial gets listed here.]

---

### Generation constraints for the automation
- 1,000–1,500 words. This is the one weekly piece allowed to run long.
- Must reference at least 2 of the week's `threads_covered` articles — this editorial is a synthesis piece, not a standalone op-ed.
- The "foreign cost → domestic cost" link is the signature move — but only use it when there's an actual dollar figure or policy tradeoff to point to, never as a rhetorical device on its own.
- More interpretive latitude than the 3x/week template, but still no claim without a traceable source from this week's reporting.
- Sign off as "6th Way Editorial," not an individual byline, unless instructed otherwise.
